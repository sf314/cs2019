#ifndef _COMPILER_OPTIONS_H_
#define _COMPILER_OPTIONS_H_

/* This header was created as a workaround to Ardino to get some compiler opions
 * set for the InvenSense Motion Driver. Used in inv_mpu.c
 */

#define MPU9250

#endif
